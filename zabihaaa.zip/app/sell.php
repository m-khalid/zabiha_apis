<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sell extends Model
{
    //
}
