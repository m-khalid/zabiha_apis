<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sliderproduct extends Model
{
    //
}
